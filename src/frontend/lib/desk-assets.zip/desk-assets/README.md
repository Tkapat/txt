Copy `stickers/` and `sketches/` into your Next.js `public/` folder, and `desk-items.ts` to `src/frontend/lib/`.
All files were generated for this project (no third-party artwork). Total size ~130 KB.
